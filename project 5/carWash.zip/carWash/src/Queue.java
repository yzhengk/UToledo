
public class Queue <E>{

	Qnode<E> queue;
	public Queue(){
		queue = new Qnode<E>();
	}
	
	public void inqueue(Qnode<E> node){
		Qnode<E> temp = queue;
		while(temp.getNext()!=null){
			temp = temp.getNext();
		}
		temp.setNext(node);
	}
	
	public Qnode<E> dequeue(){
		if(isEmpty())return null;
		Qnode<E> temp = queue.getNext();
		queue = queue.getNext();
		return temp;
	}
	
	public Qnode<E> top(){
		if(isEmpty())return null;
		return queue.getNext();
	}
	
	public int len(){
		Qnode<E> temp = queue;
		int i=0;
		while(temp.getNext()!=null){
			temp = temp.getNext();
			i++;
		}
		return i;
	}
	public boolean isEmpty(){
		if(len()==0)return true;
		else return false;
	}
}
