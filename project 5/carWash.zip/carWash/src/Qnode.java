

public class Qnode<E> {
		private E data;
		private Qnode<E> next;
		public Qnode(){
			data = null;
			next = null;
		}
		public Qnode(E pdata){
			data = pdata;
			next = null;
		}
		public E getData() {
			return data;
		}
		public void setData(E data) {
			this.data = data;
		}
		public Qnode<E> getNext() {
			return next;
		}
		public void setNext(Qnode<E> next) {
			this.next = next;
		}
}
