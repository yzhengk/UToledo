import java.util.Random;

public class Customer {

	private int t_arrival;
	private int t_wait;
	private int t_server;

	public Customer() {
		t_arrival = -1;
		t_wait = -1;
		// Customers are served in random integer intervals of 2 to 5 minutes
		t_server = (new Random()).nextInt(4) + 2;
	}

	public Customer(int p_arrival) {
		t_wait = -1;
		// Customers are served in random integer intervals of 2 to 5 minutes
		t_server = (new Random()).nextInt(4) + 2;
		t_arrival = p_arrival;
	}

	public int getT_arrival() {
		return t_arrival;
	}

	public void setT_arrival(int tArrival) {
		t_arrival = tArrival;
	}

	public int getT_wait() {
		return t_wait;
	}

	public void setT_wait(int tWait) {
		t_wait = tWait;
	}

	public int getT_server() {
		return t_server;
	}

	public void setT_server(int tServer) {
		t_server = tServer;
	}

	public int getT_completion(){
		if(t_arrival<0||t_wait<0||t_server<0)
			return -1;
		return t_arrival + t_wait + t_server;
	}
}