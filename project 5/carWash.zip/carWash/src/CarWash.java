import java.awt.GridLayout;
import java.util.Random;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class CarWash {

	public static void main(String argv[]) {
		JPanel startWin = new JPanel(new GridLayout(3, 2, 5, 5));
		JTextField hr = new JTextField();
		JTextField min = new JTextField();
		JTextField num = new JTextField();

		startWin.add(new JLabel("OPEN HOURS"));
		startWin.add(hr);
		startWin.add(new JLabel("OPEN MINUTES"));
		startWin.add(min);
		startWin.add(new JLabel("CARS NUM"));
		startWin.add(num);

		int result = JOptionPane.showConfirmDialog(null, startWin,
				"Initialization", JOptionPane.OK_CANCEL_OPTION);
		// maxTime: the number minutes for the car wash shift.
		int maxTime = 0;
		// startNum: the number of customers waiting in line when the car wash
		// opens
		int startNum = 0;
		if (result == JOptionPane.OK_OPTION) {
			if (!(hr.getText().equals(""))) {
				maxTime += 60 * Integer.parseInt(hr.getText());
			}
			if (!(min.getText().equals(""))) {
				maxTime += Integer.parseInt(min.getText());
			}
			if (!(num.getText().equals(""))) {
				startNum = Integer.parseInt(num.getText());
			}
		}
		if (startNum > 4) {
			startNum = 4;
		} else if (startNum < 0) {
			startNum = 0;
		}
		System.out.println("Total open:" + maxTime + " min");
		System.out.println("There are " + startNum + " car(s) waiting");
		System.out.println("******************************************");
		System.out.println("           *** Welcome! ***");
		System.out.println("         Ethan��s Car Wash opens");
		System.out.println("******************************************");

		Queue<Customer> line = new Queue<Customer>();
		Qnode<Customer> temp;
		int arrivelTime = nextArrivel();
		int nextServiceTime = 0;
		Customer customer;
		// a. Total number of customers served
		int totalCustomer = 0;
		// b. Number of minutes the car wash was idle
		int idleTime = 0;
		// c. Average wait time
		double averageWait = 0;
		// d. Longest wait time
		int longestWait = 0;
		// e. The number of customers that bypassed the car wash
		int bypassNum = 0;
		// Initialize the customers waiting in line
		for (int i = 0; i < startNum; i++) {
			temp = new Qnode<Customer>(new Customer(0));
			line.inqueue(temp);
		}

		for (int i = 0; i < maxTime; i++) {
			// System.out.println("time:" + (i) + " --------------------");
			if (i == arrivelTime) {
				System.out.println("A customer has arrived");
				if (line.len() >= 4) {
					System.out
							.println("Bypass: more than 4 customers waiting in line");
					bypassNum++;
				} else {
					temp = new Qnode<Customer>(new Customer(i));
					line.inqueue(temp);
					System.out.println("He(She) is waiting in line now");
				}
				arrivelTime += nextArrivel();
			}
			if (!line.isEmpty() && i >= nextServiceTime) {
				System.out.println("A customer started service");
				customer = ((Customer) line.dequeue().getData());
				customer.setT_wait(i - customer.getT_arrival());
				nextServiceTime = customer.getT_completion();
				// calculate some info
				totalCustomer++;
				averageWait += customer.getT_wait();
				if (customer.getT_wait() > longestWait)
					longestWait = customer.getT_wait();

			} else if (line.isEmpty() && i >= nextServiceTime) {
				idleTime++;
			}
		}
		averageWait = averageWait / totalCustomer;
		System.out.println("a. Total number of customers served");
		System.out.println("      " + totalCustomer);
		System.out.println("b. Number of minutes the car wash was idle");
		System.out.println("      " + idleTime);
		System.out.println("c. Average wait time");
		System.out.println("      " + ((int) (averageWait * 100)) / 100.0);
		System.out.println("d. Longest wait time");
		System.out.println("      " + longestWait);
		System.out
				.println("e. The number of customers that bypassed the car wash");
		System.out.println("      " + bypassNum);
		String message = "served num: " + totalCustomer + "\n" + "idle time: "
				+ idleTime / 60 + "h" + idleTime % 60 + "min" + "\n"
				+ "average wait: " + ((int) (averageWait * 100)) / 100.0
				+ "min\n" + "longest wait: " + longestWait + "min\n"
				+ "bypassed num: " + bypassNum + "\n";
		JOptionPane.showMessageDialog(null, message);
	}

	/**
	 * Customers arrive at the car wash in random integer intervals of 1 to 6
	 * minutes
	 * 
	 * @return
	 */
	private static int nextArrivel() {
		return ((new Random()).nextInt(6) + 1);
	}
}
