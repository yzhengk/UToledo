// expression = (a+b) * (c-d) / e + f


import javax.swing.*;
public class MainClass
{
	public static void main (String[ ] args)
	{
		BinaryExpressionTree theTree = new BinaryExpressionTree ("+/*+ab-cdef");

		Node theRoot = theTree.root;

		theTree.preorder (theRoot);

		System.out.println ( );

		theRoot = theTree.root;

		theTree.postorder (theRoot);

		System.out.println ( );

		theRoot = theTree.root;

		theTree.inorder (theRoot);

		theRoot = theTree.root;

		JOptionPane.showMessageDialog (null, "result = " + theTree.evaluate (theRoot));

		System.exit (0);
	}
}