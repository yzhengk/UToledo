public class Node
{
	private String data;
	private Node left;
	private Node right;

	public Node ( )
	{
		data = null;
		left = null;
		right = null;
	}

	public Node (String newData)
	{
		data = newData;
		left = null;
		right = null;
	}

	public void setData (String newData)
	{
		data = newData;
	}

	public void setLeft (Node newLeft)
	{
		left = newLeft;
	}

	public void setRight (Node newRight)
	{
		right = newRight;
	}

	public String getData ( )
	{
		return data;
	}

	public Node getRight ( )
	{
		return right;
	}

	public Node getLeft ( )
	{
		return left;
	}

	public boolean equals (Node theOther)
	{
		return this.data.equals (theOther.data);
	}

	public int compareTo (Node theOther)
	{
		return this.data.compareTo (theOther.data);
	}

	public String toString ( )
	{
		return this.data.toString ( );
	}
}






