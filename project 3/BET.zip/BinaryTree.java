public class BinaryTree
{
	public  Node root;


	public BinaryTree ( )
	{
		root = null;
	}

	//recursive
	public void inorder (Node current)
	{
		if (current != null)
		{
			inorder (current.getLeft ( ));
			System.out.print (current);
			inorder (current.getRight ( ));
		}
	}

	public void preorder (Node current)
	{
		if (current != null)
		{
			System.out.print (current);
			preorder (current.getLeft ( ));
			preorder (current.getRight ( ));
		}
	}

	public void postorder (Node current)
	{
		if (current != null)
		{
			postorder (current.getLeft ( ));
			postorder (current.getRight ( ));
			System.out.print (current);
		}
	}
}