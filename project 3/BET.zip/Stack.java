public class Stack
{
	private Node[] data;
	private int capacity;
	private int TOS;

	public Stack ( )
	{
		capacity = 20;
		data = new Node [capacity];
		TOS = capacity;
	}

	public Stack (int newCapacity)
	{
		capacity = newCapacity;
		data = new Node [capacity];
		TOS = capacity;
	}

	public boolean push (Node newElement)
	{
		if (TOS == 0)
			return false;
		else
		{
			data[--TOS] = newElement;
			return true;
		}
	}


	public Node pop (   )
	{
		if (TOS == capacity)
			return null;
		else
			return data[TOS++];
	}

	//dangerous leak
	public Node peek ( )
	{
		if (TOS == capacity)
			return null;
		else
			return data[TOS];
	}

	public boolean stackEmpty ( )
	{
		return (TOS == capacity);
	}

	public boolean stackFull ( )
	{
		return (TOS == 0);
	}

}






















