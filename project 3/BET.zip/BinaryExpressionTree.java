import javax.swing.*;

public class BinaryExpressionTree extends BinaryTree
{

	private String preExpression;	//original expression in prefix
	private double result;


	public BinaryExpressionTree (String newExpression)
	{
		preExpression = newExpression;
		result = 0;

		buildTree ( );
	}

	private void buildTree ( )
	{
		Stack stackOfNodes = new Stack ( );
		int nextMove = 0; //0: left, 1: right
		Node lastNode = null;

		int lenOfExpression = preExpression.length ( );

		for (int i = 0; i < lenOfExpression; i++)
		{
			String newData = "" + preExpression.charAt (i);

			Node newNode = new Node (newData);

			if (i == 0)
				root = newNode;
			else
			{
				if (nextMove == 0)
					lastNode.setLeft (newNode);
				else
				{
					lastNode = stackOfNodes.pop ( );
					lastNode.setRight (newNode);
				}
			}

			if (newData.equals ("+") || newData.equals ("-") ||
				newData.equals ("*") || newData.equals ("/"))
			{
				nextMove = 0;
				stackOfNodes.push (newNode);
				lastNode = newNode;
			}
			else
				nextMove = 1;
		}
	}

	public double evaluate (Node current)
	{
		char c;

		if (current != null)
		{
			c = current.getData ( ).charAt (0);
			switch (c)
			{
				case '+' : result = evaluate (current.getLeft ( )) + evaluate (current.getRight ( )); break;
				case '-' : result = evaluate (current.getLeft ( )) - evaluate (current.getRight ( )); break;
				case '*' : result = evaluate (current.getLeft ( )) * evaluate (current.getRight ( )); break;
				case '/' : result = evaluate (current.getLeft ( )) / evaluate (current.getRight ( )); break;
				default:
					result = getValue (c);
			}
		}

		return result;
	}

	public double getValue (char c)
	{
		String inString = JOptionPane.showInputDialog ("enter the value for " + c);
		return Double.parseDouble (inString);
	}

}





