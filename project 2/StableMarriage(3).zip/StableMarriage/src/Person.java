import java.util.List;

/**
 * this class is used to store the data structure and calculation
 * written by Li Bingcheng
 */
public class Person {
	//person name
	private String name;
	// marriage partner name ,if this person is single,this attribute value is null
	private String partnerName;
	//this index to preferences 
	private Integer priorityIndex;
	//this person's Preferences list
	private List<String> preferences;
	
	//constructor set this person's name and initialize priorityIndex value is -1
	public Person(String name){
		this.name = name;
		this.priorityIndex = -1;
	}
	 
	
	/**
	 * override the equals method, if the person's name is equal another's  name ,
	 * then these two person is equals ,user for List<Person> getIndexOf()
	 */
	@Override
	public boolean equals(Object obj) {
		if(obj == null)
			return false;
		else if(obj instanceof Person){
			if(((Person) obj).getName().equals(this.getName()))
				return true;
		}
		return false;
	}
	
	/**
	 * judge this person whether hash preference request not yet
	 * @return if have next return true,else return false
	 */
	public boolean haveNext(){
		if(this.priorityIndex + 1 < preferences.size()){
			return true;
		}
		return false;
	}
	
	/**
	 * get the Next Person who can be Marry
	 * @param womenList
	 * @return
	 */
	public Person getNextWomen(List<Person> womenList){
		String womenName = preferences.get(++this.priorityIndex);
		int womenIndex = womenList.indexOf(new Person(womenName));
		return womenList.get(womenIndex);
	}

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPartnerName() {
		return partnerName;
	}
	public void setPartnerName(String partnerName) {
		this.partnerName = partnerName;
	}
	public Integer getPriorityIndex() {
		return priorityIndex;
	}
	public void setPriorityIndex(Integer priorityIndex) {
		this.priorityIndex = priorityIndex;
	}
	public List<String> getPreferences() {
		return preferences;
	}
	public void setPreferences(List<String> preferences) {
		this.preferences = preferences;
	}
	
	
}
