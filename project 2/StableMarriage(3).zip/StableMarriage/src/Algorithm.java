import java.util.List;

/**
 * class of algorithms
 *written by Li Bingcheng
 */
public class Algorithm {
	/**
	 * Gale-Shapely Algorithm
	 * @param manList 
	 * @param womenList 
	 */
	public static void GaleShapley(List<Person> manList
			,List<Person> womenList){
		//Initialize each person to be free
		Person p;
		for(int i = 0; i < manList.size(); i++){
			p = manList.get(i);
			p.setPartnerName(null);
			p.setPriorityIndex(-1);
		}
		for(int i = 0; i < womenList.size(); i++){
			p = womenList.get(i);
			p.setPartnerName(null);
			p.setPriorityIndex(-1);
		}
		
		//if some man is free and hasn't proposed to every woman,hashManFree is true
		boolean hashManFree = true; 
		while(hashManFree){
			hashManFree = false;
			Person freeMan = null; 
			//find who man is free and hasn't proposed to every woman
			for(int i = 0 ;i < manList.size();i++){
				if(manList.get(i).getPartnerName() == null && manList.get(i).haveNext())
				{
					//exist a man is free and hasn't proposed to every woman
					hashManFree = true;
					freeMan = manList.get(i);//Choose such a man m
				} 
			}
			if(hashManFree){
				//get the woman on men's list to whom m has not yet proposed
				Person women = freeMan.getNextWomen(womenList);
				//is women is free
				if(women.getPartnerName() == null){
					freeMan.setPartnerName(women.getName());
					women.setPartnerName(freeMan.getName());
				}
				else {
					List<String> womenPreferences = women.getPreferences();
					// if women prefers this men to her fiancé m'
					if(womenPreferences.indexOf(freeMan.getName()) 
							< womenPreferences.indexOf(women.getPartnerName())){
						// assign men and women to be engaged, and m' to be free
						int oldManIndex = manList.indexOf(new Person(women.getPartnerName()));
						Person oldMan = manList.get(oldManIndex);
						oldMan.setPartnerName(null);
						freeMan.setPartnerName(women.getName());
						women.setPartnerName(freeMan.getName());
					}
				}
			}
		}
	}
}
