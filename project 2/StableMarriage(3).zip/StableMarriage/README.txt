This project Development in eclipse IDE,you can use your eclipse open this project and run ,the application's

start in MainWindow Class ,run the Main Method is ok!

In addition the The test data file must on the res/ Directory file 

or directly on bin/ Directory file if you don't  have used eclipse recompile the generated .thanks !


