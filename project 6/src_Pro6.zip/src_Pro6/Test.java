

public class Test {
	
	public static void main(String argv[]){
		SpellChecker spellChecker = new SpellChecker();
		spellChecker.main();
		
	}
}
