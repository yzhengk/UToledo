import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Pro4 {

	/**
	 * main function
	 * @param argv
	 */
	public static void main(String argv[]) {
		// print welcome
		System.out
				.println("*****************************************************");
		System.out
				.println("Welcome to the Weighted Interval Scheduling Program");
		System.out
				.println("*****************************************************");
		
		// read info from a file
		System.out.println("Please input your datafile name:");
		@SuppressWarnings("resource")
		Scanner scan = new Scanner(System.in);
		String filename = scan.nextLine();
		File file = new File(filename);
		try {
			scan = new Scanner(file);
		} catch (FileNotFoundException e) {
			System.out.println("can't open the file!");
			return;
		}
		List<Intervals> list = new ArrayList<Intervals>();
		int startTime = -1;
		int finishTime = -1;
		int weight = -1;
		while (true) {
			for (int i = 0; i < 3; i++) {
				if (!scan.hasNextInt())break;
				startTime = scan.nextInt();
				if (!scan.hasNextInt())break;
				finishTime = scan.nextInt();
				if (!scan.hasNextInt())break;
				weight = scan.nextInt();
				list.add(new Intervals(startTime, finishTime, weight));
			}
			if (!scan.hasNextInt())break;
		}
		
		// compute the result
		List<List<Integer>> resultInfo = new ArrayList<List<Integer>>();
		List<Integer> result = findOptimumSolution(list, resultInfo);

		System.out.println("Optimum value:" + result.get(result.size() - 1));
		System.out.print("Interval Sequence:");
		for (int i = 0; i < resultInfo.get(resultInfo.size() - 1).size(); i++) {
			System.out.print((resultInfo.get(resultInfo.size() - 1).get(i) + 1)
					+ " ");
		}
		System.out.println(" ");

	}

	/**
	 * initialize and compute the result
	 * @param list
	 * @param resultInfo
	 * @return
	 */
	private static List<Integer> findOptimumSolution(List<Intervals> list,
			List<List<Integer>> resultInfo) {
		List<Integer> result = new ArrayList<Integer>();

		for (int i = 0; i < list.size(); i++) {
			result.add(list.get(i).getWeight());
			resultInfo.add(new ArrayList<Integer>());
		}
		if (list.size() >= 1) {
			result.set(0, list.get(0).getWeight());
			resultInfo.get(0).add(0);
		}
		int n = 0;
		result = OptimumSolution(n, list, result, resultInfo);
		return result;
	}

	/**
	 * compute the result use recursion
	 * @param n
	 * @param list
	 * @param result
	 * @param resultInfo
	 * @return
	 */
	private static List<Integer> OptimumSolution(int n, List<Intervals> list,
			List<Integer> result, List<List<Integer>> resultInfo) {
		if (n < list.size() - 1) {
			n++;
			int startTime = list.get(n).getStartTime();
			int weight = list.get(n).getWeight();
			int newWeight = weight;
			int num = n;
			for (int i = n - 1; i >= 0; i--) {
				if (list.get(i).getFinishTime() <= startTime) {
					newWeight += result.get(i);
					num = i;
					break;
				}
			}
			if (newWeight > result.get(n - 1)) {
				result.set(n, newWeight);
				resultInfo.get(n).addAll(resultInfo.get(num));
				(resultInfo.get(n)).add(n);
			} else {
				result.set(n, result.get(n - 1));
				resultInfo.get(n).addAll(resultInfo.get(n - 1));
			}
			return OptimumSolution(n, list, result, resultInfo);
		} else {
			return result;
		}
	}

}
