
public class Intervals {
	private int startTime;
	private int finishTime;
	private int weight;
	public Intervals(){
		startTime=-1;
		finishTime = -1;
		weight = -1;
	}
	public Intervals(int pStartTime, int pFinishTime, int pWeight){
		startTime = pStartTime;
		finishTime = pFinishTime;
		weight = pWeight;
	}
	public int getStartTime() {
		return startTime;
	}
	public void setStartTime(int startTime) {
		this.startTime = startTime;
	}
	public int getFinishTime() {
		return finishTime;
	}
	public void setFinishTime(int finishTime) {
		this.finishTime = finishTime;
	}
	public int getWeight() {
		return weight;
	}
	public void setWeight(int weight) {
		this.weight = weight;
	}
	
	
}
